package onetomany.bargainingchipsgame.players;

public enum StatusMessageType 
{
	AGREEMENTREACHED;
}
