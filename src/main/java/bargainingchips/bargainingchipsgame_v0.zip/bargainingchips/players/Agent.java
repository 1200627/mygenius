package onetomany.bargainingchipsgame.players;

import java.util.concurrent.BlockingQueue;

import onetomany.bargainingchipsgame.NegotiationContext;
import onetomany.bargainingchipsgame.interactions.Offer;
import onetomany.bargainingchipsgame.players.utilityfunction.UtilityFunction;
/**
 * An agent typically has a buyer or seller role and can send an receive offers.
 * An agent has a utility function for evaluating any proposal in a given negotiation context. 
 */
public abstract class Agent implements Runnable
{
	protected String name;
	protected UtilityFunction u;
	protected NegotiationContext negotiationContext; 
	
	int k;
	
	public Agent(String name, UtilityFunction u, NegotiationContext negotiationContext,
			BlockingQueue<Offer> in, BlockingQueue<Offer> out,
			BlockingQueue<CoordinationMessage> cin, BlockingQueue<StatusMessage> cout) 
	{
		this.name = name;
		this.u = u;
		this.negotiationContext = negotiationContext;
		this.in = in;
		this.out = out;
		this.cin  = cin;
		this.cout = cout;
		k = 0;
	}
	
	// Messaging from and to the opponent
	protected BlockingQueue<Offer> in;
	protected BlockingQueue<Offer> out;
	// Messaging from and to the coordinator
	protected BlockingQueue<CoordinationMessage> cin;
	protected BlockingQueue<StatusMessage> cout;
	
	protected abstract void  receiveOffer(Offer bundle);
	
	protected abstract Offer sendOffer();
	
	protected abstract Offer sendOpeningOffer();
	
	protected abstract void  receiveCoordinationMessage(CoordinationMessage cpoll); 
	
	protected abstract StatusMessage sendStatusMessage();
	
	@Override
	public void run() 
	{
		// A buyer may send an opening offer
		Offer opening = do_sendOpeningOffer();
		if (opening != null)
			try {
				out.put(opening);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		
		while (true)
		{
			try 
			{
				// Wait for either a message from coordinator or an incoming offer from seller
				while (true)
				{
					CoordinationMessage cpoll = cin.poll();
					if (cpoll != null)
					{
						do_receiveCoordinationMessage(cpoll);
						break;
					}
					
					Offer poll = in.poll();
					if (poll != null)
					{
						do_receiveOffer(poll);
						break;
					}
				}
				
				// A sync happened, so we can send out a new offer, given the new information
				Offer sendOffer = do_sendOffer();
				out.put(sendOffer);
				
				// Pause
				Thread.sleep(500);
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void do_receiveCoordinationMessage(CoordinationMessage cpoll) 
	{
		System.out.println(this + " received coordination msg " + cpoll);
		receiveCoordinationMessage(cpoll);
	}

	protected void do_receiveOffer(Offer o) 
	{
		System.out.println(this + " received " + o 
				+ (o.isBid() ? (", with util = " + u.getUtility(o.getBundle())) : "") 
				);
		receiveOffer(o);		
	}

	protected Offer do_sendOffer()
	{
		Offer o = sendOffer();
		System.out.println(this + " sends " + o);
		k++;		
		return o;
	}
	
	protected Offer do_sendOpeningOffer() 
	{
		Offer o = sendOpeningOffer();
		if (o != null)
		{
			System.out.println(this + " sends opening offer " + o);
			k++;
		}
		return o;
	}

	@Override
	public String toString() 
	{
		return "#" + k + ": " + name;
	}
	
	public String toDescription() 
	{
		return name + " with u = " + u;
	}
}
