package onetomany.bargainingchipsgame.interactions;

import onetomany.bargainingchipsgame.Bundle;
import onetomany.bargainingchipsgame.BundleBuilder;

/**
 * An offer has two parts: (1) a bundle or null, (2) a message code: `bid', `accept', `end'.
 * When the code is 'bid', the first part is checked; for the two latter codes, the first part of the offer is null.
 * In other words, message `bid' means that offer contains a bundle which is proposed, `accept' means offer contains no bundle to propose, 
 * but an agreement with the deal (the received offer), and `end' again means that nothing to propose, and quitting the negotiation.
 * 
 * Immutable.
 */
public class Offer 
{
	/** 
	 * Message codes: 
	 * (1) `bid' [body contains a bundle], 
	 * (2) `accept' [agree with the deal (based on the rules); null body], 
	 * (3) `end' [quitting the negotiation; null body]
	 */
	private final OfferType type; 
	private final Bundle bundle;
	
	/**
	 * Creates an offer. Bundle and OfferType are immutable and therefore so is Offer.
	 */
	public Offer(Bundle b, OfferType t)
	{
		bundle = b;
		type = t;
	}

	public Offer(Offer o)
	{
		this(o.bundle, o.type);
	}
	
	/**
	 * Creates a bid. Bundle is immutable and therefore so is Offer.
	 */
	public Offer(Bundle b)
	{
		this(b, OfferType.BID);
	}

	/**
	 * @return the proposal
	 */
	public Bundle getBundle() 
	{
		return bundle;
	}
	
	@Override
	public String toString() 
	{
		if (type != OfferType.BID)
			return type.toString();
		else
			return type.toString() + ": " + bundle.toString();
	}
	
	public static Offer getSampleOffer(int qty)
	{
		return getSampleOffer("Red", qty);
	}
	
	/**
	 * Just a sample example of an offer
	 */
	public static Offer getSampleOffer(String color, int qty)
	{
		Bundle bundle = new BundleBuilder()
				.addStack(color, 7.0, qty)
				.build();
		return new Offer(bundle);
	}
	
	public boolean isBid() 
	{
		return type == OfferType.BID;
	}
	
	public boolean isEnd() 
	{
		return type == OfferType.END;
	}

	public boolean isAccept() 
	{
		return type == OfferType.ACCEPT;
	}
}