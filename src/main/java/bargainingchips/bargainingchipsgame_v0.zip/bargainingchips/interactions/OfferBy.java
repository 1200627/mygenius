package onetomany.bargainingchipsgame.interactions;
/**
 * An offer by a certain entity (Agent) with unique id.
 */
public class OfferBy extends Offer 
{
	private String sender;

	public OfferBy(String id, Offer o)
	{
		super(o);
		this.sender = id;
	}
	
	public String getSender() 
	{
		return sender;
	}
	
	@Override
	public String toString() 
	{
		return super.toString() + " by: " + sender + "";
	}
}
