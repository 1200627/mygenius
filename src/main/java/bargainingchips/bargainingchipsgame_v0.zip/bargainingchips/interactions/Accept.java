package onetomany.bargainingchipsgame.interactions;

import onetomany.bargainingchipsgame.Bundle;

public class Accept extends Offer
{
	public Accept(Offer agreement)
	{
		super(agreement.getBundle(), OfferType.ACCEPT);
	}
	
	public Bundle getAgreement()
	{
		return getBundle();
	}
}
